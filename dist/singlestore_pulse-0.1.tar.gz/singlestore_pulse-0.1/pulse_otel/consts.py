OTEL_COLLECTOR_ENDPOINT = "http://otel-collector-{PROJECTID_PLACEHOLDER}.observability.svc.cluster.local:4317"
LOCAL_TRACES_FILE = "traceloop_traces.json"
LOCAL_LOGS_FILE = "traceloop_logs.txt"
