import functools
import os
import logging
import typing
import time

from traceloop.sdk import Traceloop
from traceloop.sdk.decorators import agent, tool
from opentelemetry import _logs

from opentelemetry import trace
from opentelemetry.propagate import extract
from opentelemetry.trace import SpanKind
from opentelemetry.context import attach, set_value

from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler, LogData
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor, LogExporter, LogExportResult, SimpleLogRecordProcessor
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
    OTLPSpanExporter,
)
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import (
    OTLPLogExporter,
)
from fastapi import Request

from pulse_otel.util import (
	get_environ_vars,
	form_otel_collector_endpoint,
	_is_endpoint_reachable,
	add_session_id_to_span_attributes,
	)
from pulse_otel.consts import (
	LOCAL_TRACES_FILE,
	LOCAL_LOGS_FILE,
	PROJECT,
	LIVE_LOGS_FILE_PATH,
)
import logging

_pulse_instance = None

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

tracer = trace.get_tracer(__name__)

class Pulse:
	def __init__(
		self,
		write_to_file: bool = False,
		write_to_traceloop: bool = False,
		api_key: str = None,
		otel_collector_endpoint: str = None,
		only_live_logs: bool = False,
		enable_trace_content=True,
	):
		"""
		Initializes the main class with configuration for logging and tracing.

		Args:
			write_to_file (bool): Determines whether to write logs and traces to a file.
								  If False, logs and traces are sent to an OpenTelemetry collector.
								  Defaults to False.This mode is for local development.
			write_to_traceloop (bool): Determines whether to send logs and traces to Traceloop.
			api_key (str): The API key for Traceloop. Required if `write_to_traceloop` is True.
			otel_collector_endpoint (str): The endpoint for the OpenTelemetry collector.
			only_live_logs (bool): If True, only live logs are captured and sent to a JSONL file.
								   This is useful for debugging and development purposes.

		Behavior:
			- If `write_to_file` is False:
				- Configures an OpenTelemetry collector endpoint based on the project configuration.
				- Sets up a logger provider and an OTLP log exporter for sending logs.
				- Configures a logging handler with the specified logger provider.
				- Initializes Traceloop with the OTLP span exporter and resource attributes.
			- If `write_to_file` is True:
				- Initializes a custom log provider for file-based logging.
				- Initializes Traceloop with a custom file span exporter and resource attributes.
		"""
		start_time = time.time()
		
		global _pulse_instance

		if _pulse_instance is not None:
			logger.info("Pulse instance already exists. Skipping initialization.")
			# Copy the existing instance's attributes to this instance
			self.__dict__.update(_pulse_instance.__dict__)
			return

		try:
			if enable_trace_content:
				logger.info("[PULSE] Content tracing enabled. Prompts and completions will be logged as span attributes.")
				os.environ['TRACELOOP_TRACE_CONTENT'] = 'true'
			else:
				logger.info("[PULSE] Content tracing disabled. Prompts and completions will not be logged as span attributes.")
				os.environ['TRACELOOP_TRACE_CONTENT'] = 'false'

			self.config = get_environ_vars()
			if write_to_traceloop and api_key:
				log_exporter = self.init_log_provider()

				Traceloop.init(
					disable_batch=True,
					resource_attributes=self.config,
					api_key=api_key,
					logging_exporter=log_exporter,
				)

			elif write_to_file:

				log_exporter = self.init_log_provider()
				Traceloop.init(
					disable_batch=True,
					exporter=CustomFileSpanExporter(LOCAL_TRACES_FILE),
					resource_attributes=self.config,
					logging_exporter=log_exporter,
				)
			elif only_live_logs:
				# create json log exporter for live logs
				jsonl_file_exporter = get_jsonl_file_exporter()
				if jsonl_file_exporter is not None:
					log_provider = LoggerProvider()
					_logs.set_logger_provider(log_provider)
					log_provider.add_log_record_processor(SimpleLogRecordProcessor(jsonl_file_exporter))
					logging.root.addHandler(LoggingHandler()) # add filehandler to root logger
			else:
				if otel_collector_endpoint is None:
					try:
						projectID = self.config[str(PROJECT)]
					except KeyError:
						raise ValueError(f"Project ID '{PROJECT}' not found in configuration.")
					otel_collector_endpoint = form_otel_collector_endpoint(projectID)

				"""
					Use the provided OTLP collector endpoint
					First, a new LoggerProvider is created and set as the global logger provider. This object manages loggers and their configuration for the application. Next, an OTLPLogExporter is instantiated with the given endpoint, which is responsible for sending log records to the OTLP collector. The exporter is wrapped in a BatchLogRecordProcessor, which batches log records for efficient export, and this processor is registered with the logger provider.
				"""
				log_provider = LoggerProvider()
				_logs.set_logger_provider(log_provider)

				# create json log exporter for live logs
				jsonl_file_exporter = get_jsonl_file_exporter()
				if jsonl_file_exporter is not None:
					log_provider.add_log_record_processor(SimpleLogRecordProcessor(jsonl_file_exporter))

				if not _is_endpoint_reachable(otel_collector_endpoint):
					logger.warning(f"Warning: OTel collector endpoint {otel_collector_endpoint} is not reachable. Please enable Pulse Tracing or contact the support team for more assistance.")
					return

				log_exporter = OTLPLogExporter(endpoint=otel_collector_endpoint)
				log_provider.add_log_record_processor(BatchLogRecordProcessor(log_exporter))

				"""
					A LoggingHandler is then created, configured to capture logs at the DEBUG level and to use the custom logger provider. The Python logging system is configured via logging.basicConfig to use this handler and to set the root logger’s level to INFO. This means all logs at INFO level or higher will be processed and sent to the OTLP collector, while the handler itself is capable of handling DEBUG logs if needed.
				"""
				handler = LoggingHandler(level=logging.DEBUG, logger_provider=log_provider)

				"""
					In Python logging, both the logger and the handler have their own log levels, and both levels must be satisfied for a log record to be processed and exported.

					1. Handler Level (LoggingHandler(level=logging.DEBUG, ...)):
					This means the handler is willing to process log records at DEBUG level and above (DEBUG, INFO, WARNING, etc.).

					2. Root Logger Level (logging.basicConfig(level=logging.INFO, ...)):
					This sets the minimum level for the root logger. Only log records at INFO level and above will be passed from the logger to the handler.
				"""
				logging.basicConfig(level=logging.INFO, handlers=[handler])

				Traceloop.init(
					disable_batch=True,
					api_endpoint=otel_collector_endpoint,
					resource_attributes=self.config,
					exporter=OTLPSpanExporter(endpoint=otel_collector_endpoint, insecure=True),
					telemetry_enabled=False,
				)
		except Exception as e:
			logger.error(f"Error initializing Pulse: {e}")

		# Set the global instance
		_pulse_instance = self
		end_time = time.time()
		logger.info(f"Pulse initialized successfully in {end_time - start_time:.2f} seconds.")

	@staticmethod
	def enable_content_tracing(enabled: bool = True):
		"""
		Enables or disables content tracing by attaching a context variable.
		Sets a key called override_enable_content_tracing in the OpenTelemetry context to True right before
		making the LLM call you want to trace with prompts. This will create a new context that will instruct instrumentations to log prompts and completions as span attributes.

		With Traceloop, we set the environment variable `TRACELOOP_TRACE_CONTENT` to 'true' or 'false' based on the enabled parameter.
		Args:
			enabled (bool): A flag to enable or disable content tracing. Defaults to True.
		"""
		attach(set_value("override_enable_content_tracing", enabled))

		if enabled:
			logger.info("Content tracing enabled. Prompts and completions will be logged as span attributes.")
			os.environ['TRACELOOP_TRACE_CONTENT'] = 'true'
		else:
			logger.info("Content tracing disabled. Prompts and completions will not be logged as span attributes.")
			os.environ['TRACELOOP_TRACE_CONTENT'] = 'false'


	def init_log_provider(self):
		"""
		Initializes the log provider and sets up the logging configuration.
		"""
		# Create the log provider and processor
		log_provider = LoggerProvider()
		log_exporter = FileLogExporter(LOCAL_LOGS_FILE)
		log_provider.add_log_record_processor(BatchLogRecordProcessor(log_exporter))

		# create json log exporter for live logs
		jsonl_file_exporter = get_jsonl_file_exporter()
		if jsonl_file_exporter is not None:
			log_provider.add_log_record_processor(SimpleLogRecordProcessor(jsonl_file_exporter))

		# Set the log provider
		_logs.set_logger_provider(log_provider)

		# Create a standard logging handler to bridge stdlib and OTel
		handler = LoggingHandler()
		logging.root.setLevel(logging.INFO)
		logging.root.addHandler(handler)
		return log_exporter

def pulse_tool(_func=None, *, name=None, enable_content_tracing=True):
	"""
	Decorator to register a function as a tool. Can be used as @pulse_tool, @pulse_tool("name"), or @pulse_tool(name="name").
	If no argument is passed, uses the function name as the tool name.
	Args:
		_func: The function to be decorated.
		name: Optional name for the tool. If not provided, the function name is used.
		enable_content_tracing: Whether to enable content tracing for this tool. Defaults to False.
	Returns:
		A decorator that registers the function as a tool with the specified name.

	Usage:
		@pulse_tool("my_tool")
		def my_function():
			# Function implementation

		@pulse_tool
		def my_function():
			# Function implementation

		@pulse_tool(name="my_tool", enable_content_tracing=True)
		def my_function():
			# Function implementation
	"""
	def decorator(func):
		tool_name = name or func.__name__
		decorated_func = tool(tool_name)(func)
		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			Pulse.enable_content_tracing(enable_content_tracing)
			return decorated_func(*args, **kwargs)
		return wrapper

	if _func is None:
		# Called as @pulse_tool() or @pulse_tool(name="...", enable_content_tracing=...)
		return decorator
	elif isinstance(_func, str):
		# Called as @pulse_tool("name") - this is actually the old pattern
		# We should handle this for backward compatibility
		def wrapper(func):
			tool_name = _func
			decorated_func = tool(tool_name)(func)
			@functools.wraps(func)
			def inner_wrapper(*args, **kwargs):
				Pulse.enable_content_tracing(enable_content_tracing)
				return decorated_func(*args, **kwargs)
			return inner_wrapper
		return wrapper
	else:
		# Called as @pulse_tool (without parentheses)
		return decorator(_func)

def pulse_agent(name, enable_content_tracing=True):
	"""
	A decorator factory that wraps a function with additional tracing and session ID logic.

	Args:
		name (str): The name to be used for the agent decorator.
		enable_content_tracing (bool): Whether to enable content tracing for this agent. Defaults to False.

	Returns:
		function: A decorator that wraps the target function, adding session ID to span attributes
		before invoking the decorated agent function.

	Usage:
		@pulse_agent("my_agent")
		def my_function(...):
			...

		@pulse_agent(name="my_agent", enable_content_tracing=True)
		def my_function(...):
			...
	"""
	def decorator(func):
		decorated_func = agent(name)(func)

		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			add_session_id_to_span_attributes(**kwargs)
			Pulse.enable_content_tracing(enable_content_tracing)
			return decorated_func(*args, **kwargs)

		return wrapper

	return decorator


def observe(name):
	"""
	A decorator factory that instruments a function for observability using opentelemetry tracing.
	Args:
		name (str): The name of the span to be created for tracing.
	Returns:
		Callable: A decorator that wraps the target function, extracting opentelemetry tracing context
		from the incoming request (if available), and starts a new tracing span using
		the provided name. If no context is found, a new span is started without context.
	Behavior:
		- Adds session ID to span attributes if available in kwargs.
		- Attempts to extract a tracing context from the 'request' argument or from positional arguments.
		- Starts a tracing span with the extracted context (if present) or as a new trace.
		- Logs debug information about the tracing context and span creation.
		- Supports usage both within and outside of HTTP request contexts.
	Example:
		@observe("my_function_span")
		def my_function(request: Request, ...):
			...
	"""
	def decorator(func):
		decorated_func = agent(name)(func)
		logger.debug("Decorating function with observe:", name)

		@functools.wraps(func)
		def wrapper(*args, **kwargs):
			add_session_id_to_span_attributes(**kwargs)
			request: Request = kwargs.get("request")
			if request is None:
				for arg in args:
					if isinstance(arg, Request):
						request = arg
						break

			# Extract context from request if available
			ctx = extract(request.headers) if request else None

			if ctx:
				logger.debug(f"Starting span with context: {ctx}")
				# Start span with context
				with tracer.start_as_current_span(name, context=ctx, kind=SpanKind.SERVER):
					return decorated_func(*args, **kwargs)
			else:
				logger.debug("No context found, starting span without context.")
				
				# Start span without context
				# This is useful for cases where we want to start a span without any specific context
				# e.g., when the function is called outside of an HTTP request context
				# or when we want to create a fresh new trace or context is not properly propagated.
				return decorated_func(*args, **kwargs)

		return wrapper

	return decorator

class CustomFileSpanExporter(SpanExporter):
    def __init__(self, file_name):
        self.file_name = file_name

    def export(self, spans):
        with open(self.file_name, "a") as f:
            for span in spans:
                f.write(span.to_json() + "\n")
        return SpanExportResult.SUCCESS


class FileLogExporter(LogExporter):
    def __init__(self, file_name):
        self.file_name = file_name

    def export(self, batch):
        with open(self.file_name, "a") as f:
            for log_data in batch:
                log_record = log_data.log_record  # Access the actual log record
                formatted_log = (
                    f"Timestamp: {log_record.timestamp}, "
                    f"Severity: {log_record.severity_text}, "
                    f"Message: {log_record.body}, "
					f"Span ID : {format(log_record.span_id, '016x')}, "
					f"Trace ID : {format(log_record.trace_id, '016x')}"
                )
                f.write(formatted_log + "\n")
        return LogExportResult.SUCCESS

    def shutdown(self):
        # No specific shutdown logic needed for file-based exporting
        pass

def get_jsonl_log_file_path():
	"""
	Gets the filename for live logs from env vars
	"""
	return os.getenv(LIVE_LOGS_FILE_PATH)

def get_jsonl_file_exporter():
	"""
	get json log exporter if env var exists and parent director exists
	"""
	jsonl_log_file_path = get_jsonl_log_file_path()
	if jsonl_log_file_path is not None and jsonl_log_file_path != "" and os.path.exists(os.path.dirname(jsonl_log_file_path)):
		logger.debug(f"Logging to file: {jsonl_log_file_path}")
		return JSONLFileLogExporter(jsonl_log_file_path)
	logger.debug("No JSON log file provided. Skipping JSON log export.")
	return None

class JSONLFileLogExporter(LogExporter):
	def __init__(self, file_path):
		self.file_path = file_path
		try:
			self.f = open(self.file_path, 'a', encoding='utf-8')
		except Exception as e:
			logger.error(f"Failed to open file {self.file_path}: {e}")
			self.f = None

	def export(self, batch: typing.Sequence[LogData]) -> LogExportResult:
		if self.f is None:
			return LogExportResult.FAILURE
		try:
			for r in batch:
				self.f.write(r.log_record.to_json(None) + '\n')
				self.f.flush()
			return LogExportResult.SUCCESS
		except Exception as e:
			logger.error(f"Failed to write to file {self.file_path}: {e}")
			return LogExportResult.FAILURE

	def shutdown(self):
		if self.f:
			self.f.close()
