OTEL_COLLECTOR_ENDPOINT = "otel-{PROJECTID_PLACEHOLDER}.observability.svc.cluster.local:4317"
